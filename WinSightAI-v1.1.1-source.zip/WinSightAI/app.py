import queue
import calendar
import json
import hashlib
import sys
import threading
import tkinter as tk
from datetime import datetime, timedelta
from tkinter import filedialog, messagebox

import customtkinter as ctk
import core
import pathumma

ctk.set_appearance_mode('dark')
ctk.set_default_color_theme('blue')

class App(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title('WinSight AI v1.1.1 | Pathumma Windows Log Analysis')
        self.geometry('1100x820')
        self.minsize(850, 650)
        self.record = None
        self.jobs = queue.Queue()
        self.progress = queue.Queue()
        self.buttons = []
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(2, weight=1)
        ctk.CTkLabel(self, text='WinSight AI  v1.1.1 · Pathumma', font=ctk.CTkFont(size=26, weight='bold')).grid(row=0, column=0, padx=20, pady=10, sticky='w')
        ctk.CTkLabel(self, text='อ่าน Windows Events เท่านั้น • ผลจากกฎเป็นข้อสันนิษฐาน • AI สรุปอาจสร้างข้อมูลผิด').grid(row=1, column=0, padx=20, sticky='w')
        tabs = ctk.CTkTabview(self)
        tabs.grid(row=2, column=0, sticky='nsew', padx=20, pady=10)
        main = tabs.add('Analysis')
        hist = tabs.add('History')
        main.grid_columnconfigure(0, weight=1)
        main.grid_rowconfigure(1, weight=1)
        main.grid_rowconfigure(4, weight=1)
        bar = ctk.CTkFrame(main)
        bar.grid(row=0, column=0, sticky='ew')
        quick = ctk.CTkFrame(bar, fg_color='transparent')
        quick.pack(fill='x', padx=4, pady=(4, 0))
        self.button(quick, 'Import TXT', self.import_file).pack(side='left', padx=4, pady=5)
        ctk.CTkLabel(quick, text='ย้อนหลัง (ชั่วโมง)').pack(side='left', padx=4)
        self.hours = ctk.CTkEntry(quick, width=55)
        self.hours.insert(0, '24')
        self.hours.pack(side='left')
        self.button(quick, 'Auto Scan', self.auto_scan).pack(side='left', padx=5)
        ctk.CTkLabel(quick, text='สูงสุด/channel').pack(side='left', padx=4)
        self.scan_limit = ctk.CTkOptionMenu(quick, values=['100', '200', '500'], width=75)
        self.scan_limit.set('100')
        self.scan_limit.pack(side='left', padx=4)
        dates = ctk.CTkFrame(bar, fg_color='transparent')
        dates.pack(fill='x', padx=8, pady=(1, 0))
        now = datetime.now(core.THAI_TIMEZONE).replace(microsecond=0)
        start_default = now - timedelta(hours=24)
        ctk.CTkLabel(dates, text='เริ่ม').grid(row=0, column=0, padx=(0, 5))
        self.scan_start_date = ctk.CTkEntry(dates, width=112, placeholder_text='YYYY-MM-DD')
        self.scan_start_date.insert(0, start_default.strftime('%Y-%m-%d'))
        self.scan_start_date.grid(row=0, column=1, padx=3)
        self.scan_start_time = ctk.CTkEntry(dates, width=86, placeholder_text='HH:MM:SS')
        self.scan_start_time.insert(0, start_default.strftime('%H:%M:%S'))
        start_calendar = self.button(dates, 'วัน', lambda: self.choose_date(self.scan_start_date))
        start_calendar.configure(width=30)
        start_calendar.grid(row=0, column=2, padx=1)
        self.scan_start_time.grid(row=0, column=3, padx=3)
        ctk.CTkLabel(dates, text='ถึง').grid(row=0, column=4, padx=5)
        self.scan_end_date = ctk.CTkEntry(dates, width=112, placeholder_text='YYYY-MM-DD')
        self.scan_end_date.insert(0, now.strftime('%Y-%m-%d'))
        self.scan_end_date.grid(row=0, column=5, padx=3)
        self.scan_end_time = ctk.CTkEntry(dates, width=86, placeholder_text='HH:MM:SS')
        self.scan_end_time.insert(0, now.strftime('%H:%M:%S'))
        end_calendar = self.button(dates, 'วัน', lambda: self.choose_date(self.scan_end_date))
        end_calendar.configure(width=30)
        end_calendar.grid(row=0, column=6, padx=1)
        self.scan_end_time.grid(row=0, column=7, padx=3)
        range_button = self.button(dates, 'Scan ช่วงวัน/เวลา', self.scan_dates)
        range_button.configure(width=135)
        range_button.grid(row=0, column=8, padx=8, pady=4)
        ctk.CTkLabel(bar, text='เวลาไทย UTC+7 • ปี ค.ศ. YYYY-MM-DD / HH:MM:SS • ช่วงไม่เกิน 31 วัน • Critical/Error/Warning', font=('Tahoma', 11)).pack(anchor='w', padx=10, pady=(0, 4))
        self.input = ctk.CTkTextbox(main, wrap='word', font=('Tahoma', 14))
        self.input.grid(row=1, column=0, sticky='nsew', pady=8)
        self.input.insert('1.0', 'วาง Windows log จริงที่นี่ แล้วกด Analyze')
        controls = ctk.CTkFrame(main)
        controls.grid(row=2, column=0, sticky='ew')
        self.button(controls, 'Analyze (Local)', self.analyze).pack(side='left', padx=4, pady=6)
        self.rate = ctk.CTkOptionMenu(controls, values=['20', '30', '40'], width=65)
        self.rate.set('30')
        self.button(controls, 'AI / ลองส่วนที่เหลือ', self.ai).pack(side='left', padx=4)
        self.button(controls, 'ส่งใหม่ทั้งหมด', lambda: self.ai(force=True)).pack(side='left', padx=4)
        self.button(controls, 'Save History', self.save).pack(side='left', padx=4)
        self.button(controls, 'Export TXT', self.export).pack(side='left', padx=4)
        ctk.CTkLabel(main, text='Pathumma TextQA: 1–10,000 คำ • แบ่งอัตโนมัติ • ตรวจข้อมูลส่วนตัวก่อนส่ง').grid(row=3, column=0, sticky='w', pady=5)
        self.output = ctk.CTkTextbox(main, wrap='word', font=('Tahoma', 14))
        self.output.grid(row=4, column=0, sticky='nsew')
        hist.grid_columnconfigure(0, weight=1)
        hist.grid_rowconfigure(1, weight=1)
        self.button(hist, 'Refresh History', self.refresh).grid(row=0, column=0, sticky='w', pady=5)
        self.listbox = tk.Listbox(hist, bg='#202020', fg='white', font=('Tahoma', 12))
        self.listbox.grid(row=1, column=0, sticky='nsew')
        self.listbox.bind('<<ListboxSelect>>', self.load_history)
        self.status = ctk.CTkLabel(self, text='พร้อมใช้งาน | คีย์อ่านจาก .env ข้างโปรแกรม')
        self.status.grid(row=3, column=0, padx=20, pady=6, sticky='w')
        self.after(100, self.poll)
        self.guard(self.refresh)

    def button(self, parent, text, command):
        b = ctk.CTkButton(parent, text=text, command=lambda: self.guard(command), width=105)
        self.buttons.append(b)
        return b

    def guard(self, fn):
        try:
            fn()
        except Exception as e:
            messagebox.showerror('WinSight AI', core.sanitize(str(e)))

    def show(self):
        self.output.configure(state='normal')
        self.output.delete('1.0', 'end')
        self.output.insert('1.0', core.sanitize(core.report(self.record)))
        self.output.configure(state='disabled')

    def analyze(self):
        previous_record = self.record
        self.record = core.make_record(self.input.get('1.0', 'end'))
        if previous_record and previous_record['source'] == self.record['source'] and previous_record.get('scan'):
            self.record['scan'] = previous_record['scan']
        self.show()
        self.status.configure(text=f"วิเคราะห์แล้ว | {core.word_count(self.record['source'])} คำ | {len(self.record['diagnosis'])} กฎตรงกัน")

    def background(self, work, done):
        for b in self.buttons:
            b.configure(state='disabled')
        self.input.configure(state='disabled')
        self.listbox.configure(state='disabled')
        self.status.configure(text='กำลังทำงาน…')
        def run():
            try:
                self.jobs.put((done, work(), None))
            except Exception as e:
                self.jobs.put((done, None, core.sanitize(str(e))))
        threading.Thread(target=run, daemon=True).start()

    def poll(self):
        try:
            while True:
                current, total = self.progress.get_nowait()
                self.status.configure(text=f'กำลังสรุป AI ส่วน {current}/{total}…')
        except queue.Empty:
            pass
        try:
            done, value, error = self.jobs.get_nowait()
            for b in self.buttons:
                b.configure(state='normal')
            self.input.configure(state='normal')
            self.listbox.configure(state='normal')
            self.status.configure(text='พร้อมใช้งาน')
            if error:
                messagebox.showerror('WinSight AI', error)
            else:
                self.guard(lambda: done(value))
        except queue.Empty:
            pass
        self.after(100, self.poll)

    def auto_scan(self):
        hours = core._scan_number(self.hours.get(), 'ชั่วโมงย้อนหลัง ', 1, 168)
        limit = core._scan_number(self.scan_limit.get(), 'จำนวนสูงสุดต่อ channel ', 1, 500)
        self.background(lambda: core.scan(hours, limit), self.scan_done)

    def choose_date(self, entry):
        try:
            initial = datetime.strptime(entry.get().strip(), '%Y-%m-%d')
        except ValueError:
            initial = datetime.now(core.THAI_TIMEZONE)
        year_month = [initial.year, initial.month]
        popup = ctk.CTkToplevel(self)
        popup.title('เลือกวันที่ (ปี ค.ศ. / เวลาไทย)')
        popup.resizable(False, False)
        popup.transient(self)
        popup.grab_set()
        months = ('มกราคม', 'กุมภาพันธ์', 'มีนาคม', 'เมษายน', 'พฤษภาคม', 'มิถุนายน',
                  'กรกฎาคม', 'สิงหาคม', 'กันยายน', 'ตุลาคม', 'พฤศจิกายน', 'ธันวาคม')
        header = ctk.CTkFrame(popup, fg_color='transparent')
        header.pack(fill='x', padx=8, pady=8)
        title = ctk.CTkLabel(header, width=190)
        days = ctk.CTkFrame(popup, fg_color='transparent')
        days.pack(padx=8, pady=(0, 8))

        def select(value):
            entry.delete(0, 'end')
            entry.insert(0, value)
            popup.destroy()

        def render():
            year, month = year_month
            title.configure(text=f'{months[month - 1]} {year}')
            for widget in days.winfo_children():
                widget.destroy()
            for col, label in enumerate(('จ', 'อ', 'พ', 'พฤ', 'ศ', 'ส', 'อา')):
                ctk.CTkLabel(days, text=label, width=36).grid(row=0, column=col, padx=2)
            for row, week in enumerate(calendar.monthcalendar(year, month), 1):
                for col, day in enumerate(week):
                    if day:
                        value = f'{year:04d}-{month:02d}-{day:02d}'
                        options = {'fg_color': '#245d8c'} if value == initial.strftime('%Y-%m-%d') else {}
                        ctk.CTkButton(days, text=str(day), width=36, height=30,
                                      command=lambda date=value: select(date), **options).grid(row=row, column=col, padx=2, pady=2)

        def move(change):
            absolute = year_month[0] * 12 + year_month[1] - 1 + change
            year, month = divmod(absolute, 12)
            if 1 <= year <= 9999:
                year_month[:] = [year, month + 1]
                render()

        ctk.CTkButton(header, text='‹', width=32, command=lambda: move(-1)).pack(side='left')
        title.pack(side='left', padx=4)
        ctk.CTkButton(header, text='›', width=32, command=lambda: move(1)).pack(side='left')
        ctk.CTkButton(popup, text='วันนี้', command=lambda: select(datetime.now(core.THAI_TIMEZONE).strftime('%Y-%m-%d'))).pack(pady=(0, 10))
        render()

    def scan_dates(self):
        start, end = core.scan_range(
            self.scan_start_date.get().strip() + ' ' + self.scan_start_time.get().strip(),
            self.scan_end_date.get().strip() + ' ' + self.scan_end_time.get().strip())
        limit = core._scan_number(self.scan_limit.get(), 'จำนวนสูงสุดต่อ channel ', 1, 500)
        self.background(lambda: core.scan(limit=limit, start=start, end=end), self.scan_done)

    def scan_done(self, value):
        self.input.delete('1.0', 'end')
        self.input.insert('1.0', core.event_text(value['events']))
        if value['events']:
            self.analyze()
            self.record['scan'] = {k: v for k, v in value.items() if k != 'events'}
            self.record['scan']['event_count'] = len(value['events'])
            self.show()
        else:
            self.record = None
            self.output.configure(state='normal')
            self.output.delete('1.0', 'end')
            self.output.configure(state='disabled')
        note = f"อ่าน {len(value['events'])} เหตุการณ์"
        if value.get('truncated_channels'):
            note += ' | ถึงเพดานใน ' + ', '.join(value['truncated_channels']) + ' กรุณาลดช่วงเวลาหรือเพิ่มจำนวนสูงสุด'
        if value['warnings']:
            note += ' | ' + ' / '.join(value['warnings'])
        self.status.configure(text=note)

    def ai(self, force=False):
        current_source = core.sanitize(core.evidence.extract_source(self.input.get('1.0', 'end').strip()))
        if not self.record or self.record['source'] != current_source:
            self.analyze()
        source = self.record['source']
        rate = int(self.rate.get())
        pathumma.split(source)
        source_hash = self.record.get('summary_source_hash')
        previous = None if force else {'parts': self.record.get('summary_parts', []),
                                      'source_hash': source_hash, 'policy_version': self.record.get('summary_policy_version')}
        def done(result):
            self.record['summary'] = result['summary']
            self.record['summary_parts'] = result['parts']
            self.record['summary_complete'] = result['complete']
            self.record['ai_provider'] = result.get('provider', 'AIForThai Pathumma TextQA')
            self.record['summary_source_hash'] = result.get('source_hash')
            self.record['summary_policy_version'] = result.get('policy_version')
            self.record['ai_group_count'] = result.get('group_count')
            self.show()
            self.status.configure(text='สรุป AI ครบทุกส่วน — ตรวจเทียบหลักฐานก่อนใช้งาน' if result['complete'] else 'สรุป AI ไม่ครบ — ดูส่วนที่ล้มเหลวในรายงาน; ยังบันทึกและ Export ได้')
        self.background(lambda: pathumma.analyze(source, progress=lambda current, total: self.progress.put((current, total)), previous=previous), done)

    def save(self):
        if not self.record:
            raise ValueError('กรุณาวิเคราะห์ก่อน')
        core.save(self.record)
        self.refresh()
        self.status.configure(text='บันทึก History แล้ว (เก็บล่าสุด 100 รายการ)')

    def refresh(self):
        self.records = list(reversed(core.history()))
        self.listbox.delete(0, 'end')
        for r in self.records:
            self.listbox.insert('end', r['time'] + ' | ' + r['source'][:75].replace('\n', ' '))

    def load_history(self, event):
        if self.listbox.curselection():
            self.record = self.records[self.listbox.curselection()[0]]
            self.input.configure(state='normal')
            self.input.delete('1.0', 'end')
            self.input.insert('1.0', self.record['source'])
            self.show()
            self.status.configure(text='เปิดประวัติแล้ว ดูผลใน Analysis')

    def import_file(self):
        path = filedialog.askopenfilename(filetypes=[('Text logs', '*.txt *.log')])
        if path:
            with open(path, encoding='utf-8-sig') as f:
                text = f.read(2_000_001)
            if len(text) > 2_000_000:
                raise ValueError('ไฟล์ใหญ่เกิน 2 ล้านตัวอักษร')
            self.input.delete('1.0', 'end')
            self.input.insert('1.0', core.sanitize(core.evidence.extract_source(text)))

    def export(self):
        if not self.record:
            raise ValueError('กรุณาวิเคราะห์ก่อน')
        path = filedialog.asksaveasfilename(defaultextension='.txt', filetypes=[('Text', '*.txt')])
        if path:
            with open(path, 'w', encoding='utf-8') as f:
                f.write(core.sanitize(core.report(self.record)))
            self.status.configure(text='Export สำเร็จ')

if __name__ == '__main__':
    app = App()
    if '--self-test' in sys.argv:
        app.update()
        app.input.delete('1.0', 'end')
        app.input.insert('1.0', 'Test fixture: Provider: Kernel-Power Event ID: 41')
        app.analyze()
        assert app.record['diagnosis'][0]['rule'] == 'unexpected_shutdown'
        assert core.word_count('ระบบบันทึกเหตุการณ์ผิดพลาด') > 1
        app.update()
        folder = core.BASE / 'verification'
        folder.mkdir(exist_ok=True)
        (folder / 'frozen_smoke.json').write_text(json.dumps({'gui': 'passed', 'rules': 'passed', 'thai_tokenizer': 'passed'}), encoding='utf-8')
        app.destroy()
    else:
        app.mainloop()
