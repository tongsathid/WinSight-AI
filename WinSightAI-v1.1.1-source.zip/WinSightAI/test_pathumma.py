import unittest
from unittest.mock import patch, Mock
import pathumma

class Tests(unittest.TestCase):
    def test_split_preserves_and_short_input(self):
        self.assertEqual(pathumma.split('Event ID: 41'), ['Event ID: 41'])
        text = ('เวลา: Event ID: 7034\nService stopped unexpectedly\n' * 700)
        parts = pathumma.split(text)
        self.assertEqual(''.join(parts), text)
        self.assertTrue(all(len(p) <= 5000 for p in parts))

    def test_form_contract(self):
        response = Mock(status_code=200)
        response.json.return_value = {'content': 'พบเหตุการณ์หยุดบริการ'}
        with patch('pathumma.key', return_value='test-only'), patch('pathumma.requests.post', return_value=response) as post:
            self.assertIn('หยุดบริการ', pathumma.summarize('Event ID: 7034'))
        self.assertEqual(post.call_args.args[0], pathumma.ENDPOINT)
        self.assertIn('system_prompt', post.call_args.kwargs['data'])
        self.assertNotIn('json', post.call_args.kwargs)
        self.assertIn('7034', post.call_args.kwargs['data']['instruction'])

    def test_missing_key(self):
        with patch('pathumma.key', return_value=''), patch('pathumma.requests.post') as post:
            with self.assertRaises(ValueError):
                pathumma.summarize('Event ID: 41')
            post.assert_not_called()

    def test_bad_response_and_permissions(self):
        for code in (401, 403, 429, 500):
            with patch('pathumma.key', return_value='test-only'), patch('pathumma.requests.post', return_value=Mock(status_code=code)):
                with self.assertRaisesRegex(ValueError, str(code)):
                    pathumma.summarize('Event ID: 41')
        response = Mock(status_code=200)
        response.json.return_value = {'other': 'x'}
        with patch('pathumma.key', return_value='test-only'), patch('pathumma.requests.post', return_value=response):
            with self.assertRaises(ValueError):
                pathumma.summarize('Event ID: 41')

    def test_partial(self):
        source = 'Event ID: 41\n' * 1000
        with patch('pathumma.summarize', side_effect=['สรุปแรก', ValueError('HTTP 500')]) as call:
            result = pathumma.analyze(source)
        self.assertFalse(result['complete'])
        self.assertEqual(call.call_count, 2)
        self.assertIn('สรุปแรก', result['summary'])

    def test_english_retry_to_thai(self):
        first, second = Mock(status_code=200), Mock(status_code=200)
        first.json.return_value = {'content': 'The service could not be started.'}
        second.json.return_value = {'content': 'หลักฐาน: พบเหตุการณ์ VSS เริ่มทำงานไม่ได้ รหัส 0x80070422 ยังไม่ยืนยันสาเหตุ'}
        with patch('pathumma.key', return_value='test-only'), patch('pathumma.requests.post', side_effect=[first, second]) as post:
            self.assertIn('หลักฐาน', pathumma.summarize('VSS error 0x80070422'))
        self.assertEqual(post.call_count, 2)
        self.assertIn('ตอบเป็นภาษาไทยเท่านั้น', post.call_args.kwargs['data']['instruction'])

    def test_english_not_success(self):
        response = Mock(status_code=200)
        response.json.return_value = {'content': 'The error indicates a service failure.'}
        with patch('pathumma.key', return_value='test-only'), patch('pathumma.requests.post', return_value=response) as post:
            result = pathumma.analyze('Event ID: 41')
        self.assertFalse(result['complete'])
        self.assertNotIn('The error', result['summary'])
        self.assertEqual(post.call_count, 2)

    def test_repetition(self):
        text = '\n'.join(f'{i}. ให้ตรวจสอบข้อมูลของบริการก่อนสรุปสาเหตุ' for i in range(1, 8))
        self.assertFalse(pathumma.acceptable(text))

    def test_thai_with_identifiers(self):
        self.assertTrue(pathumma.acceptable('หลักฐาน: พบข้อผิดพลาดจากบริการ Microsoft-Windows-DistributedCOM Event ID 10016 ยังไม่ยืนยันสาเหตุและควรตรวจเวลาเกิดเหตุเพิ่มเติม'))

    def test_bad_repair_command(self):
        self.assertFalse(pathumma.acceptable('ให้ตรวจสอบสถานะของบริการก่อนสรุปสาเหตุ\n`sc config vss start`'))

    def test_resume_only_unsuccessful_parts(self):
        source = 'Event ID: 41\n' * 1000
        thai = 'พบเหตุการณ์ตามข้อมูลต้นฉบับ ยังไม่สามารถยืนยันสาเหตุได้'
        with patch('pathumma.summarize', side_effect=[thai, ValueError('HTTP 500')]):
            first = pathumma.analyze(source)
        with patch('pathumma.summarize', return_value=thai) as request:
            second = pathumma.analyze(source, previous=first)
        self.assertTrue(second['complete'])
        self.assertEqual(request.call_count, len(first['parts']) - 1)
        self.assertTrue(second['parts'][0]['reused'])

    def test_changed_document_never_reuses(self):
        thai = 'พบเหตุการณ์ตามข้อมูลต้นฉบับ ยังไม่สามารถยืนยันสาเหตุได้'
        with patch('pathumma.summarize', return_value=thai):
            first = pathumma.analyze('Event ID: 41')
        with patch('pathumma.summarize', return_value=thai) as request:
            second = pathumma.analyze('Event ID: 42', previous=first)
        request.assert_called_once()
        self.assertNotEqual(second['source_hash'], first['source_hash'])

    def test_full_retry_and_completed_resume(self):
        thai = 'พบเหตุการณ์ตามข้อมูลต้นฉบับ ยังไม่สามารถยืนยันสาเหตุได้'
        with patch('pathumma.summarize', return_value=thai):
            first = pathumma.analyze('Event ID: 41')
        with patch('pathumma.summarize', return_value=thai) as request:
            second = pathumma.analyze('Event ID: 41', previous=first)
            request.assert_not_called()
            self.assertTrue(second['complete'])
            pathumma.analyze('Event ID: 41')
            request.assert_called_once()

    def test_repeated_clause_inside_one_paragraph(self):
        clause = 'การตั้งค่าสิทธิ์ของบริการนี้ไม่อนุญาตให้เรียกใช้ส่วนประกอบตามรายละเอียดที่บันทึกไว้ในระบบ '
        self.assertFalse(pathumma.acceptable(clause * 5))

    def test_grounding_rejects_invented_versions_ids_and_codes(self):
        source = '[E001]\nEvent ID: 10016\nProvider: Microsoft-Windows-DistributedCOM\nSID S-1-5-21-1001'
        for extra in ('Windows Server 2016', 'Event ID: 1001', '0xDEADBEEF', '{8BC3F05E-D86B-11D0-A075-00C04FB68820}'):
            self.assertFalse(pathumma.acceptable('[E001] พบเหตุการณ์ตามหลักฐาน แต่เพิ่มข้อความ ' + extra, source))
        self.assertTrue(pathumma.acceptable('[E001] พบ Event ID: 10016 ตามหลักฐาน ยังไม่ยืนยันสาเหตุ', source))

    def test_quality_failure_does_not_block_later_evidence(self):
        parts = ['[E001]\nEvent ID: 41', '[E002]\nEvent ID: 42', '[E003]\nEvent ID: 43']
        valid = lambda ref: ref + ' พบเหตุการณ์ตามหลักฐาน ยังไม่ยืนยันสาเหตุ'
        outputs = [valid('[E001]'), 'The service failed.', 'The service failed.', valid('[E003]')]
        with patch('pathumma.split', return_value=parts), patch('pathumma._generate', side_effect=outputs) as call:
            result = pathumma.analyze('manual log')
        self.assertEqual(call.call_count, 4)
        self.assertEqual([p['status'] for p in result['parts']], ['success', 'quality_failed', 'success'])
        self.assertFalse(result['complete'])

    def test_provider_errors_stop_batch(self):
        parts = ['[E001]\nEvent ID: 41', '[E002]\nEvent ID: 42', '[E003]\nEvent ID: 43']
        with patch('pathumma.split', return_value=parts), patch('pathumma.summarize', side_effect=['สรุปส่วนแรก', pathumma.ProviderError('HTTP 429')]) as call:
            result = pathumma.analyze('manual log')
        self.assertEqual(call.call_count, 2)
        self.assertEqual([p['status'] for p in result['parts']], ['success', 'failed', 'not_sent'])

    def test_stale_policy_cache_is_regenerated(self):
        thai = 'พบเหตุการณ์ตามข้อมูลต้นฉบับ ยังไม่สามารถยืนยันสาเหตุได้'
        with patch('pathumma.summarize', return_value=thai):
            first = pathumma.analyze('Event ID: 41')
        first['policy_version'] = 'old'
        with patch('pathumma.summarize', return_value=thai) as call:
            pathumma.analyze('Event ID: 41', previous=first)
        call.assert_called_once()

    def test_truncated_response_not_successful(self):
        response = Mock(status_code=200)
        response.json.return_value = {'content': 'พบข้อผิดพลาดตามข้อมูลต้นฉบับ', 'finish_reason': 'length'}
        with patch('pathumma.key', return_value='test-only'), patch('pathumma.requests.post', return_value=response) as call:
            with self.assertRaises(pathumma.QualityError):
                pathumma.summarize('Event ID: 41')
        self.assertEqual(call.call_count, 2)

    def test_unclosed_guid_and_missing_group_refs(self):
        self.assertFalse(pathumma.acceptable('พบปัญหาตามหลักฐาน CLSID {8BC3F05E-D86B-11D0'))
        self.assertFalse(pathumma.acceptable('พบปัญหาตามหลักฐาน ยังไม่ยืนยันสาเหตุ', '[E001]\nEvent ID: 41\n[E002]\nEvent ID: 42'))

    def test_invented_count_date_and_thai_os_alias(self):
        source = '[E001]\nEvent ID: 13\nจำนวนจริง: 11\nเวลาแรก: 2026-10-13T15:45:15+07:00\nVSS error'
        for claim in ('พบ 99 ครั้ง', 'วันที่ 2020-01-01', 'เวลา 11:20:00', 'Windows เซิร์ฟเวอร์ 2016', 'วินโดวส์ 11'):
            self.assertFalse(pathumma.acceptable('[E001] พบข้อผิดพลาดตามข้อมูลจริง ' + claim, source))
        self.assertTrue(pathumma.acceptable('[E001] พบข้อผิดพลาด 11 ครั้ง ยังไม่ยืนยันสาเหตุ', source))

    def test_state_changing_commands_anywhere_rejected(self):
        for cmd in ('Restart-Service VSS', 'Stop-Service VSS', 'Set-ItemProperty', 'Disable-WindowsOptionalFeature', 'sc config vss start=auto'):
            self.assertFalse(pathumma.acceptable('พบเหตุการณ์ตามหลักฐาน และให้ใช้ ' + cmd))

    def test_bounded_round_and_resume(self):
        parts = [f'Event ID: {i}' for i in range(17)]
        thai = 'พบเหตุการณ์ตามข้อมูลต้นฉบับ ยังไม่สามารถยืนยันสาเหตุได้'
        with patch('pathumma.split', return_value=parts), patch('pathumma.summarize', return_value=thai) as call:
            first = pathumma.analyze('manual log')
            self.assertEqual(call.call_count, 12)
        self.assertFalse(first['complete'])
        self.assertIn('เพดาน', first['parts'][12]['error'])
        with patch('pathumma.split', return_value=parts), patch('pathumma.summarize', return_value=thai) as call:
            second = pathumma.analyze('manual log', previous=first)
        self.assertEqual(call.call_count, 5)
        self.assertTrue(second['complete'])

if __name__ == '__main__':
    unittest.main()
