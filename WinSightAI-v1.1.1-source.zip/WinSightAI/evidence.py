"""Deterministic Windows event parsing and grouping. No model-generated evidence."""
import re
from datetime import datetime
from collections import Counter

HEADER = re.compile(r'^เวลา:\s*(?P<time>[^\n|]+?)\s*\|\s*Channel:\s*(?P<channel>[^\n|]+?)\s*\|\s*Event ID:\s*(?P<event_id>\d+)\s*\|\s*Provider:\s*(?P<provider>[^\n|]+?)\s*\|\s*Level:\s*(?P<level>[^\n]+)\s*$', re.M)
SID = re.compile(r'\bS-\d+(?:-\d+)+\b', re.I)

def extract_source(text):
    text = text.strip()
    marker = 'หลักฐานจริง (ข้อมูลที่รับเข้า)'
    if text.startswith('WinSight AI ') and marker in text:
        text = text.split(marker, 1)[1].strip()
        text = re.split(r'\r?\n\s*\r?\n(?:ผลจากกฎ|AI summary)', text, maxsplit=1)[0]
    return text.strip()

def parse_events(text):
    text = extract_source(text)
    headers = list(HEADER.finditer(text))
    events = []
    for index, match in enumerate(headers):
        event = {k: v.strip() for k, v in match.groupdict().items()}
        event['event_id'] = int(event['event_id'])
        event['message'] = text[match.end():headers[index+1].start() if index+1 < len(headers) else len(text)].strip()
        event['source_index'] = index + 1
        events.append(event)
    return events

def _time_key(value):
    try:
        value = re.sub(r'(\.\d{6})\d+(?=[+-]|Z|$)', r'\1', value)
        parsed = datetime.fromisoformat(value.replace('Z', '+00:00'))
        return (0, parsed.timestamp())
    except (ValueError, OSError):
        return (1, value)

def group_events(events):
    grouped = {}
    for event in events:
        # SID values can vary, while CLSID/APPID and error text remain distinct.
        normalized = re.sub(r'\s+', ' ', SID.sub('[SID]', event['message'])).strip()
        signature = (event['channel'], event['provider'], event['event_id'], event['level'], normalized)
        if signature not in grouped:
            grouped[signature] = {**event, 'ref': f'E{len(grouped)+1:03d}', 'count': 0,
                                  'first_time': event['time'], 'last_time': event['time'], 'source_indexes': []}
        group = grouped[signature]
        group['count'] += 1
        group['source_indexes'].append(event.get('source_index', len(group['source_indexes'])+1))
        if _time_key(event['time']) < _time_key(group['first_time']):
            group['first_time'] = event['time']
        if _time_key(event['time']) > _time_key(group['last_time']):
            group['last_time'] = event['time']
    return list(grouped.values())

def description(group):
    provider, event_id, message = group['provider'].casefold(), group['event_id'], group['message'].casefold()
    if provider == 'vss' and event_id in (13, 8193):
        return 'VSS บันทึกข้อผิดพลาดระหว่างเริ่มทำงาน/สร้างตัวประสานบริการ'
    if 'distributedcom' in provider and event_id == 10016:
        return 'DCOM แจ้งเรื่องสิทธิ์เรียกใช้ COM ตามข้อความเหตุการณ์'
    if 'distributedcom' in provider and event_id == 10010:
        return 'DCOM บันทึกว่าการลงทะเบียนเซิร์ฟเวอร์เกินเวลาที่กำหนด'
    if provider == 'service control manager':
        if event_id in (7031, 7034):
            return 'บริการหยุดโดยไม่คาดหมายตามข้อความเหตุการณ์'
        if event_id in (7000, 7001, 7024):
            return 'บริการเริ่มไม่ได้หรือหยุดพร้อมข้อผิดพลาดตามข้อความเหตุการณ์'
    if 'hyper-v-hypervisor' in provider and 'launch failed' in message:
        return 'ข้อความระบุว่า Hypervisor เริ่มทำงานไม่ได้'
    if 'kernel-boot' in provider and 'vsm' in message:
        return 'ข้อความระบุว่า Virtual Secure Mode ยังไม่ได้เริ่มทำงาน'
    if 'kernel-power' in provider and event_id == 41:
        return 'บันทึกเหตุการณ์เกี่ยวกับการเริ่มระบบหลังปิดไม่สมบูรณ์ ยังไม่ยืนยันสาเหตุ'
    if 'delaying system shutdown' in message:
        return 'ข้อความระบุว่าโปรเซสหน่วงการปิดระบบ'
    return 'พบเหตุการณ์ตามข้อมูลต้นฉบับ ต้องตรวจข้อความและบริบทเพิ่มเติม'

def local_summary(text):
    events = parse_events(text)
    if not events:
        return 'ไม่มีหัว Windows Events ที่อ่านเป็นโครงสร้างได้ — ยังวิเคราะห์ข้อความทั่วไปด้วยกฎได้ แต่ไม่นับจำนวนเหตุการณ์จากตัวเลขในเนื้อหา'
    groups = group_events(events)
    levels = Counter(e['level'].casefold() for e in events)
    times = sorted((e['time'] for e in events), key=_time_key)
    rows = [f"อ่านหลักฐาน {len(events)} เหตุการณ์ • จัดกลุ่มข้อความคล้ายกัน {len(groups)} กลุ่ม",
            f"Error {levels['error']} • Warning {levels['warning']} • Critical {levels['critical']} • ระดับอื่น {len(events)-sum(levels[k] for k in ('error','warning','critical'))}",
            f'เวลาในหลักฐาน: {times[0]} ถึง {times[-1]}',
            'กลุ่มต่างกันตาม Channel / Provider / Event ID / Level / ข้อความ (ละค่าตัวเลข SID เฉพาะตอนจัดกลุ่ม)', '']
    priority = {'critical': 0, 'error': 1, 'warning': 2}
    for group in sorted(groups, key=lambda g: (priority.get(g['level'].casefold(), 3), -g['count'])):
        rows.extend([f"[{group['ref']}] {description(group)}",
                     f"  {group['count']} ครั้ง • {group['channel']} • Event ID {group['event_id']} • {group['provider']} • {group['level']}",
                     f"  ช่วงเวลา {group['first_time']} ถึง {group['last_time']}"])
        codes = list(dict.fromkeys(re.findall(r'\b0x[0-9a-fA-F]+\b', group['message'])))
        if codes:
            rows.append('  รหัสที่พบจริง: ' + ', '.join(codes))
    rows.append('\nจำนวนครั้งและช่วงเวลาคำนวณจากหลักฐานที่รับเข้า ไม่ยืนยันสาเหตุ และไม่รวมเหตุการณ์ที่ไม่ได้อ่านมา')
    return '\n'.join(rows)

def local_findings(text):
    groups = group_events(parse_events(text))
    results = []
    for group in groups:
        description_text = description(group)
        provider = group['provider'].casefold()
        if provider == 'vss':
            advice = 'ตรวจสถานะ VSS และบริการที่เกี่ยวข้องแบบอ่านอย่างเดียว พร้อมรหัส error และเหตุการณ์เวลาเดียวกัน ยังไม่สรุปว่าฮาร์ดแวร์เสีย'
        elif 'distributedcom' in provider:
            advice = 'ตรวจ CLSID/APPID และแอปที่เกี่ยวข้อง รวมทั้งอาการจริงเวลาเดียวกัน ไม่แก้สิทธิ์ DCOM จาก warning เพียงรายการเดียว'
        elif provider == 'service control manager':
            advice = 'ตรวจชื่อบริการ สถานะ และ dependency จากรายการบริการแบบอ่านอย่างเดียว เทียบเวลาเกิดกับการเปิด/ปิดโปรแกรม'
        elif 'hyper-v' in provider or 'kernel-boot' in provider:
            advice = 'ตรวจสถานะ virtualization และฟีเจอร์ที่แอปต้องใช้ก่อน ยังไม่เปลี่ยน BIOS หรือปิดระบบความปลอดภัยจาก log นี้'
        else:
            advice = 'ตรวจข้อความเหตุการณ์และรายการก่อน/หลังเวลาเดียวกันแบบอ่านอย่างเดียว ต้องมีบริบทอาการก่อนเสนอวิธีแก้'
        results.append({'rule': group['ref'], 'finding': description_text,
                        'advice': advice,
                        'count': group['count'], 'event_id': group['event_id'], 'provider': group['provider'],
                        'evidence': [f"[{group['ref']}] {group['first_time']} ถึง {group['last_time']} — {group['message'][:600]}"],
                        'confidence': 'ข้อมูลจาก log และคำอธิบายด้วยกฎ ไม่ใช่สาเหตุยืนยัน'})
    return results

def _private_redact(message):
    message = SID.sub('[SID ปิดบัง]', message)
    message = re.sub(r'(?i)\bto the user\s+[^\n]+?(?=\s+SID|\s+\[SID)', 'to the user [ผู้ใช้ปิดบัง]', message)
    return message

def prepare_batches(text, max_chars=3500, max_groups=None):
    if max_groups is not None and (isinstance(max_groups, bool) or not isinstance(max_groups, int) or max_groups < 1):
        raise ValueError('max_groups ต้องเป็นจำนวนเต็มมากกว่า 0')
    groups = group_events(parse_events(text))
    if not groups:
        return []
    cards = []
    for group in groups:
        prefix = (f"[{group['ref']}]\nChannel: {group['channel']}\nEvent ID: {group['event_id']}\nProvider: {group['provider']}\n"
                  f"Level: {group['level']}\nจำนวนจริง: {group['count']}\nเวลาแรก: {group['first_time']}\nเวลาสุดท้าย: {group['last_time']}\n"
                  f"คำอธิบายจากกฎ: {description(group)}\n")
        codes = list(dict.fromkeys(re.findall(r'\b0x[0-9a-fA-F]+\b', group['message'])))
        if codes:
            prefix += 'รหัส error ในข้อความจริง: ' + ', '.join(codes) + '\n'
        message = _private_redact(group['message'])
        budget = max_chars - len(prefix) - 120
        if budget < 100:
            raise ValueError('metadata เหตุการณ์ยาวเกินงบข้อความสำหรับ API')
        if len(message) <= budget:
            cards.append(prefix + 'ข้อความตัวอย่างจากกลุ่ม:\n' + message)
        else:
            # Explicit segments of one unusually long event; no hidden truncation.
            slices = [message[i:i+budget] for i in range(0, len(message), budget)]
            for index, part in enumerate(slices, 1):
                cards.append(prefix + f'ข้อความตัวอย่างตอน {index}/{len(slices)} (เหตุการณ์กลุ่มเดียวกัน ไม่เพิ่มจำนวน):\n' + part)
    batches, current, current_refs = [], '', set()
    for card in cards:
        card_ref = re.match(r'\[E\d{3}\]', card).group(0)
        over_groups = max_groups is not None and len(current_refs | {card_ref}) > max_groups
        if current and (len(current) + len(card) + 2 > max_chars or over_groups):
            batches.append(current)
            current = ''
            current_refs = set()
        current += ('\n\n' if current else '') + card
        current_refs.add(card_ref)
    if current:
        batches.append(current)
    return batches
