"""Behavioral regression tests for faithful event preparation.

Synthetic fixtures are safe to distribute. Optional private-report tests inspect
only files already supplied by the user; they never print or copy log content.
"""
import unittest
from collections import Counter
from pathlib import Path

import evidence


def event(event_id=10016, provider='Microsoft-Windows-DistributedCOM',
          message='Local Activation permission was not granted.',
          time='2026-10-13T16:42:57+07:00', channel='System', level='Warning'):
    return (f'เวลา: {time} | Channel: {channel} | Event ID: {event_id} | '
            f'Provider: {provider} | Level: {level}\n{message}')


CLSID_A = '{11111111-1111-1111-1111-111111111111}'
CLSID_B = '{22222222-2222-2222-2222-222222222222}'


class EvidenceTests(unittest.TestCase):
    def test_manual_source_internal_whitespace_remains_exact(self):
        source = 'first log line\n\nsecond log line with  two spaces'
        self.assertEqual(evidence.extract_source(source), source)

    def test_export_extracts_only_original_evidence(self):
        source = event(8193, 'VSS', 'CoCreateInstance failed: 0x80070422.',
                       channel='Application', level='Error')
        report = ('WinSight AI v1.0.4\n2026-10-13T08:00:00+00:00\n\n'
                  'หลักฐานจริง (ข้อมูลที่รับเข้า)\n' + source +
                  '\n\nผลจากกฎ — เป็นข้อสันนิษฐาน\n[]\n\n'
                  'AI summary — อาจคลาดเคลื่อน\nWindows Server 2016 Event ID 1000')
        extracted = evidence.extract_source(report)
        self.assertEqual(extracted, source)
        self.assertNotIn('Windows Server 2016', extracted)
        self.assertEqual(len(evidence.parse_events(report)), 1)

    def test_windows_crlf_export_never_leaks_generated_analysis_into_evidence(self):
        source = event(8193, 'VSS', 'The service failed: 0x80070422.',
                       channel='Application', level='Error')
        report = ('WinSight AI v1.0.4\n2026-10-13T08:00:00+00:00\n\n'
                  'หลักฐานจริง (ข้อมูลที่รับเข้า)\n' + source +
                  '\n\nผลจากกฎ — เป็นข้อสันนิษฐาน\n[]\n\n'
                  'AI summary — อาจคลาดเคลื่อน\nWindows Server 2016 Event ID 1000')
        parsed = evidence.parse_events(report.replace('\n', '\r\n'))
        self.assertEqual(len(parsed), 1)
        self.assertNotIn('Windows Server 2016', parsed[0]['message'])
        self.assertNotIn('ผลจากกฎ', parsed[0]['message'])

    def test_parse_multiline_message_does_not_make_fake_event_ids(self):
        source = event(message='First line.\nSID S-1-5-21-1000-1001\nEvent ID 1000 in quoted body.')
        events = evidence.parse_events(source)
        self.assertEqual(len(events), 1)
        parsed = events[0]
        self.assertEqual(int(parsed['event_id']), 10016)
        self.assertEqual(parsed['channel'], 'System')
        self.assertEqual(parsed['provider'], 'Microsoft-Windows-DistributedCOM')
        self.assertEqual(parsed['level'], 'Warning')
        self.assertIn('SID S-1-5-21-1000-1001', parsed['message'])
        self.assertIn('Event ID 1000 in quoted body.', parsed['message'])

    def test_unstructured_manual_text_is_not_invented_into_events(self):
        self.assertEqual(evidence.parse_events('SID S-1-5-21-153-2004-1001'), [])

    def test_duplicate_group_preserves_count_and_time_span(self):
        early = '2026-10-13T15:00:00+07:00'
        late = '2026-10-13T17:00:00+07:00'
        source = '\n\n'.join([event(time=late), event(time=early), event(time=late)])
        groups = evidence.group_events(evidence.parse_events(source))
        self.assertEqual(len(groups), 1)
        group = groups[0]
        self.assertEqual(group['ref'], 'E001')
        self.assertEqual(group['count'], 3)
        self.assertEqual(group['first_time'], early)
        self.assertEqual(group['last_time'], late)
        self.assertEqual(sorted(group['source_indexes']), [1, 2, 3])

    def test_sid_changes_group_together_clsid_changes_remain_separate(self):
        def message(sid, clsid):
            return f'COM Server with CLSID {clsid}; Local Activation for SID ({sid}) is denied.'
        source = '\n\n'.join([
            event(message=message('S-1-5-21-123-1001', CLSID_A)),
            event(message=message('S-1-5-21-456-1002', CLSID_A)),
            event(message=message('S-1-5-21-123-1001', CLSID_B)),
        ])
        groups = evidence.group_events(evidence.parse_events(source))
        self.assertEqual(len(groups), 2)
        self.assertEqual(sorted(g['count'] for g in groups), [1, 2])
        self.assertEqual(sum(g['count'] for g in groups), 3)
        self.assertEqual({g['ref'] for g in groups}, {'E001', 'E002'})

    def test_different_event_ids_providers_levels_and_channels_are_not_merged(self):
        source = '\n\n'.join([
            event(7034, 'Service Control Manager', 'Service stopped.', level='Error'),
            event(7024, 'Service Control Manager', 'Service stopped.', level='Error'),
            event(7034, 'OtherProvider', 'Service stopped.', level='Error'),
            event(7034, 'Service Control Manager', 'Service stopped.', level='Warning'),
            event(7034, 'Service Control Manager', 'Service stopped.',
                  channel='Application', level='Error'),
        ])
        groups = evidence.group_events(evidence.parse_events(source))
        self.assertEqual(len(groups), 5)
        self.assertEqual(sum(g['count'] for g in groups), 5)

    def test_error_codes_preserve_different_evidence_groups(self):
        source = '\n\n'.join([
            event(8193, 'VSS', 'CoCreateInstance failed with 0x80070422.', level='Error'),
            event(8193, 'VSS', 'CoCreateInstance failed with 0x80070005.', level='Error'),
        ])
        groups = evidence.group_events(evidence.parse_events(source))
        self.assertEqual(len(groups), 2)
        self.assertTrue(any('0x80070422' in g['message'] for g in groups))
        self.assertTrue(any('0x80070005' in g['message'] for g in groups))

    def test_local_summary_uses_real_header_id_not_sid_digits(self):
        source = event(message='Activation failed for SID S-1-5-21-153-2004-1001.')
        summary = evidence.local_summary(source)
        self.assertIn('10016', summary)
        self.assertNotIn('app_crash', summary)
        self.assertNotIn('โปรแกรม crash', summary)
        self.assertNotIn('โปรแกรมล้ม', summary)

    def test_local_summary_describes_vss_without_inventing_os_version(self):
        source = '\n\n'.join([
            event(8193, 'VSS', 'CoCreateInstance failed: 0x80070422. Service cannot start.',
                  channel='Application', level='Error'),
            event(13, 'VSS', 'VSS COM server cannot start: 0x80070422.',
                  channel='Application', level='Error'),
        ])
        summary = evidence.local_summary(source)
        self.assertIn('VSS', summary)
        self.assertIn('0x80070422', summary)
        self.assertNotIn('Windows Server 2016', summary)
        self.assertNotIn('PSU เสีย', summary)

    def test_compact_cards_cover_all_groups_with_real_counts_and_times(self):
        source = '\n\n'.join([
            event(8193, 'VSS', 'CoCreateInstance failed: 0x80070422.',
                  channel='Application', level='Error', time='2026-10-13T15:00:00+07:00'),
            event(8193, 'VSS', 'CoCreateInstance failed: 0x80070422.',
                  channel='Application', level='Error', time='2026-10-13T16:00:00+07:00'),
            event(7034, 'Service Control Manager', 'The Example service stopped unexpectedly.',
                  level='Error'),
        ])
        groups = evidence.group_events(evidence.parse_events(source))
        batches = evidence.prepare_batches(source, max_chars=3500)
        prepared = '\n'.join(batches)
        self.assertTrue(batches)
        self.assertTrue(all(len(batch) <= 3500 for batch in batches))
        for group in groups:
            self.assertIn(group['ref'], prepared)
            self.assertIn(str(group['count']), prepared)
            self.assertIn(str(group['event_id']), prepared)
            self.assertIn(group['first_time'], prepared)
            self.assertIn(group['last_time'], prepared)
        self.assertIn('0x80070422', prepared)

    def test_oversized_event_still_retains_its_header_reference_and_codes(self):
        source = event(8193, 'VSS', 'An unusually long diagnostic message. ' * 300 +
                       '\nThe service failed with 0x80070422.',
                       channel='Application', level='Error')
        prepared = '\n'.join(evidence.prepare_batches(source, max_chars=3500))
        self.assertIn('E001', prepared)
        self.assertIn('8193', prepared)
        self.assertIn('VSS', prepared)
        self.assertIn('0x80070422', prepared)

    def test_repeated_events_reduce_api_payload_without_changing_original(self):
        source = '\n\n'.join(event(8193, 'VSS', 'CoCreateInstance failed with 0x80070422.',
                                  channel='Application', level='Error') for _ in range(50))
        batches = evidence.prepare_batches(source)
        self.assertEqual(len(batches), 1)
        self.assertIn('50', batches[0])
        self.assertEqual(len(evidence.parse_events(source)), 50)
        self.assertLess(len(batches[0]), len(source) // 5)

    def test_private_latest_report_counts(self):
        path = Path.home() / '.codex' / 'attachments' / 'f755d601-9019-46d0-a98e-bde73e49b939' / 'ข้อความที่วาง.txt'
        if not path.exists():
            self.skipTest('Optional original user attachment is unavailable.')
        parsed = evidence.parse_events(path.read_text(encoding='utf-8-sig'))
        self.assertEqual(len(parsed), 49)
        self.assertEqual(Counter(int(e['event_id']) for e in parsed),
                         Counter({10016: 27, 8193: 11, 13: 11}))
        groups = evidence.group_events(parsed)
        self.assertEqual(sum(g['count'] for g in groups), 49)
        self.assertEqual(sorted(i for g in groups for i in g['source_indexes']), list(range(1, 50)))

    def test_private_earlier_report_counts(self):
        path = Path.home() / '.codex' / 'attachments' / '094c5e40-4854-46b8-a872-95a3c727bf28' / 'ข้อความที่วาง.txt'
        if not path.exists():
            self.skipTest('Optional original user attachment is unavailable.')
        parsed = evidence.parse_events(path.read_text(encoding='utf-8-sig'))
        self.assertEqual(len(parsed), 155)
        expected = {13: 50, 8193: 50, 10016: 25, 10010: 18, 42: 3, 124: 3,
                    7024: 2, 7034: 2, 1077: 1, 100: 1}
        self.assertEqual(Counter(int(e['event_id']) for e in parsed), Counter(expected))
        self.assertEqual(sum(g['count'] for g in evidence.group_events(parsed)), 155)


if __name__ == '__main__':
    unittest.main()
