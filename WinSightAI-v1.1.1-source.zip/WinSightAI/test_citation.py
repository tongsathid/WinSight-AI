"""Citation ownership and per-group request regression tests.

Only synthetic Windows events and mocked model responses are used. These tests
never connect to AIForThai, read user logs, or print credentials.
"""
import copy
import re
import unittest
from unittest.mock import patch

import evidence
import pathumma


def event(event_id, provider, message, minute=0, channel='Application', level='Error'):
    return (f'เวลา: 2026-10-13T16:{minute:02d}:00+07:00 | Channel: {channel} | '
            f'Event ID: {event_id} | Provider: {provider} | Level: {level}\n{message}')


SOURCE = '\n\n'.join([
    event(8193, 'VSS', 'CoCreateInstance failed with 0x80070422.'),
    event(13, 'VSS', 'COM server failed to start with 0x80070422.', minute=1),
    event(10016, 'Microsoft-Windows-DistributedCOM',
          'Local Activation permission denied.', minute=2, channel='System', level='Warning'),
])

THAI = 'พบเหตุการณ์ตามหลักฐานที่ส่งมา ยังไม่สามารถยืนยันสาเหตุได้ ควรตรวจข้อความและบริบทเพิ่มเติม'


class CitationTests(unittest.TestCase):
    def test_single_group_does_not_require_model_to_repeat_app_reference(self):
        source = '[E001]\nEvent ID: 8193\nProvider: VSS\n0x80070422'
        self.assertTrue(pathumma.acceptable(THAI, source))

    def test_single_group_still_rejects_reference_to_unsent_evidence(self):
        source = '[E001]\nEvent ID: 8193\nProvider: VSS'
        self.assertFalse(pathumma.acceptable('[E002] ' + THAI, source))
        self.assertFalse(pathumma.acceptable('[E001] [E002] ' + THAI, source))

    def test_missing_or_incomplete_multi_group_citations_still_fail(self):
        source = '[E001]\nEvent ID: 8193\n[E002]\nEvent ID: 13'
        for output in (THAI, '[E001] ' + THAI):
            with self.subTest(output=output):
                self.assertFalse(pathumma.acceptable(output, source))
        self.assertTrue(pathumma.acceptable('[E001] [E002] ' + THAI, source))

    def test_one_request_per_distinct_real_group_and_app_labels_all_results(self):
        outputs = [
            'พบ Event ID: 8193 จาก VSS พร้อมรหัส 0x80070422 ตามหลักฐาน ยังไม่ยืนยันสาเหตุ',
            'พบ Event ID: 13 จาก VSS พร้อมรหัส 0x80070422 ตามหลักฐาน ยังไม่ยืนยันสาเหตุ',
            'พบ Event ID: 10016 จาก Microsoft-Windows-DistributedCOM ตามหลักฐาน ยังไม่ยืนยันสาเหตุ',
        ]
        with patch('pathumma._generate', side_effect=outputs) as generate:
            result = pathumma.analyze(SOURCE)
        self.assertTrue(result['complete'])
        self.assertEqual(generate.call_count, 3)
        self.assertEqual(result['source_event_count'], 3)
        self.assertEqual(result['group_count'], 3)
        expected = [('[E001]', '8193'), ('[E002]', '13'), ('[E003]', '10016')]
        for call, item, (ref, event_id) in zip(generate.call_args_list, result['parts'], expected):
            payload = call.args[0]
            self.assertEqual(set(re.findall(r'\[E\d{3}\]', payload)), {ref})
            self.assertEqual(set(re.findall(r'Event ID:\s*(\d+)', payload)), {event_id})
            self.assertEqual(item['evidence_refs'], [ref])
            self.assertIn('กลุ่มหลักฐาน: ' + ref, result['summary'])
            self.assertEqual(item['status'], 'success')

    def test_no_single_group_exemption_for_invented_event_id_or_code(self):
        source = '[E001]\nEvent ID: 8193\nProvider: VSS\n0x80070422'
        for extra in ('Event ID: 1001', '0xDEADBEEF', 'Windows Server 2016'):
            with self.subTest(extra=extra):
                self.assertFalse(pathumma.acceptable(THAI + ' ' + extra, source))

    def test_duplicate_events_are_one_request_with_original_count(self):
        source = '\n\n'.join(event(8193, 'VSS', 'CoCreateInstance failed with 0x80070422.', minute=i)
                             for i in range(20))
        with patch('pathumma._generate', return_value=THAI) as generate:
            result = pathumma.analyze(source)
        self.assertTrue(result['complete'])
        generate.assert_called_once()
        self.assertEqual(result['group_count'], 1)
        self.assertEqual(result['source_event_count'], 20)
        self.assertIn('จำนวนจริง: 20', generate.call_args.args[0])
        self.assertEqual(result['parts'][0]['evidence_refs'], ['[E001]'])

    def test_unknown_reference_is_retried_then_rejected_without_blocking_next_group(self):
        source = '\n\n'.join(SOURCE.split('\n\n')[:2])
        with patch('pathumma._generate', side_effect=['[E009] ' + THAI, '[E009] ' + THAI, THAI]) as generate:
            result = pathumma.analyze(source)
        self.assertEqual(generate.call_count, 3)
        self.assertEqual([item['status'] for item in result['parts']], ['quality_failed', 'success'])
        self.assertFalse(result['complete'])
        self.assertNotIn('[E009]', result['summary'])

    def test_old_citation_policy_cache_is_regenerated_for_same_source(self):
        with patch('pathumma._generate', return_value=THAI):
            previous = pathumma.analyze(SOURCE)
        previous = copy.deepcopy(previous)
        previous['policy_version'] = 'grounded-groups-2026-10-v1'
        self.assertNotEqual(previous['policy_version'], pathumma.POLICY_VERSION)
        with patch('pathumma._generate', return_value=THAI) as generate:
            result = pathumma.analyze(SOURCE, previous=previous)
        self.assertEqual(generate.call_count, 3)
        self.assertTrue(result['complete'])
        self.assertFalse(any(item.get('reused') for item in result['parts']))

    def test_current_policy_resumes_successful_reference_free_answers(self):
        with patch('pathumma._generate', return_value=THAI):
            previous = pathumma.analyze(SOURCE)
        with patch('pathumma._generate') as generate:
            result = pathumma.analyze(SOURCE, previous=previous)
        generate.assert_not_called()
        self.assertTrue(result['complete'])
        self.assertTrue(all(item.get('reused') for item in result['parts']))

    def test_max_groups_one_never_combines_distinct_group_identifiers(self):
        batches = evidence.prepare_batches(SOURCE, max_chars=3500, max_groups=1)
        self.assertEqual(len(batches), 3)
        self.assertEqual([set(re.findall(r'\[E\d{3}\]', batch)) for batch in batches],
                         [{'[E001]'}, {'[E002]'}, {'[E003]'}])
        self.assertTrue(all(len(batch) <= 3500 for batch in batches))

    def test_long_single_event_segments_keep_one_source_reference_and_count(self):
        source = event(8193, 'VSS', 'Detailed diagnostic content. ' * 350 + '0x80070422')
        batches = evidence.prepare_batches(source, max_chars=3500, max_groups=1)
        self.assertGreater(len(batches), 1)
        for batch in batches:
            self.assertEqual(set(re.findall(r'\[E\d{3}\]', batch)), {'[E001]'})
            self.assertIn('จำนวนจริง: 1', batch)
            self.assertIn('0x80070422', batch)
            self.assertLessEqual(len(batch), 3500)
        self.assertEqual(len(evidence.parse_events(source)), 1)


if __name__ == '__main__':
    unittest.main()
