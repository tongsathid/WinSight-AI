import json
import unittest
from datetime import datetime, timedelta, timezone
from types import SimpleNamespace
from unittest.mock import Mock, patch

import core


class ScanRangeTests(unittest.TestCase):
    def response(self, **overrides):
        data = {'events': [], 'warnings': [], 'truncated_channels': []}
        data.update(overrides)
        return Mock(returncode=0, stdout=json.dumps(data).encode('utf-8-sig'))

    def test_naive_ui_time_is_thailand_local(self):
        parsed = core.parse_scan_datetime('2026-10-13 16:30')
        self.assertEqual(parsed.utcoffset(), timedelta(hours=7))
        self.assertEqual(parsed.astimezone(timezone.utc).hour, 9)
        self.assertEqual(parsed.second, 0)

    def test_aware_iso_is_converted_to_same_instant(self):
        for value in ('2026-10-13T09:30:12Z', '2026-10-13T11:30:12+02:00',
                      datetime(2026, 10, 13, 9, 30, 12, tzinfo=timezone.utc)):
            parsed = core.parse_scan_datetime(value)
            self.assertEqual(parsed.isoformat(), '2026-10-13T16:30:12+07:00')

    def test_reject_invalid_dates_times_and_injection(self):
        for value in ('2026-02-30 12:00', '2026-10-13 25:00', '2026-10-13',
                      "2026-10-13 12:00'; Remove-Item C:\\", '2026-10-13 12:00+99:00', None):
            with self.subTest(value=value), self.assertRaises(ValueError):
                core.parse_scan_datetime(value)

    def test_order_and_maximum_range(self):
        start = '2026-10-01 00:00:00'
        core.scan_range(start, '2026-11-01 00:00:00')
        core.scan_range(start, start)
        with self.assertRaisesRegex(ValueError, '31'):
            core.scan_range(start, '2026-11-01 00:00:01')
        with self.assertRaisesRegex(ValueError, 'สิ้นสุด'):
            core.scan_range('2026-10-13 12:00', '2026-10-13 11:59')

    def test_explicit_range_request_and_metadata(self):
        response = self.response(truncated_channels=['System'])
        with patch('core.sys.platform', 'win32'), patch('core.subprocess.run', return_value=response) as run:
            result = core.scan(limit=200, start='2026-10-12 16:00', end='2026-10-13 17:30')
        command = run.call_args.args[0]
        self.assertEqual(command[:4], ['powershell.exe', '-NoProfile', '-NonInteractive', '-Command'])
        script = command[4]
        self.assertIn('2026-10-12T09:00:00.000000+00:00', script)
        self.assertIn('2026-10-13T10:30:00.000000+00:00', script)
        self.assertIn('StartTime=$start;EndTime=$end;Level=1,2,3', script)
        self.assertIn('-MaxEvents 201', script)
        self.assertIn('Select-Object -First 200', script)
        self.assertNotIn('Clear-EventLog', script)
        self.assertEqual(result['start_time'], '2026-10-12T16:00:00+07:00')
        self.assertEqual(result['end_time'], '2026-10-13T17:30:00+07:00')
        self.assertEqual(result['limit_per_channel'], 200)
        self.assertEqual(result['truncated_channels'], ['System'])
        self.assertEqual(run.call_args.kwargs['creationflags'], 0x08000000)
        self.assertNotIn('shell', run.call_args.kwargs)

    def test_lookback_remains_supported(self):
        with patch('core.sys.platform', 'win32'), patch('core.subprocess.run', return_value=self.response()):
            result = core.scan(168, 500)
        start = datetime.fromisoformat(result['start_time'])
        end = datetime.fromisoformat(result['end_time'])
        self.assertEqual(end - start, timedelta(hours=168))

    def test_bad_range_never_starts_process(self):
        invalid = [dict(start='2026-10-13 12:00'), dict(end='2026-10-13 12:00'),
                   dict(start='2026-10-13 12:00', end='2026-10-12 12:00'),
                   dict(start="'; arbitrary command", end='2026-10-13 12:00'),
                   dict(hours=0), dict(hours='1.5'), dict(limit=501), dict(limit=True)]
        with patch('core.sys.platform', 'win32'), patch('core.subprocess.run') as run:
            for kwargs in invalid:
                with self.subTest(kwargs=kwargs), self.assertRaises(ValueError):
                    core.scan(**kwargs)
            run.assert_not_called()

    def test_failure_and_bad_response(self):
        with patch('core.sys.platform', 'win32'):
            for response in (Mock(returncode=1, stdout=b''), Mock(returncode=0, stdout=b'invalid'),
                             Mock(returncode=0, stdout=b'[]'), Mock(returncode=0, stdout=b'{}')):
                with patch('core.subprocess.run', return_value=response), self.assertRaises(ValueError):
                    core.scan()
            for failure in (OSError(), core.subprocess.TimeoutExpired('powershell', 60)):
                with patch('core.subprocess.run', side_effect=failure), self.assertRaises(ValueError):
                    core.scan()

    def test_ui_range_captures_values_and_reports_scan_metadata(self):
        from app import App
        event = {'Time': '2026-10-13T12:00:00+07:00', 'LogName': 'System', 'Id': 7034,
                 'ProviderName': 'Service Control Manager', 'LevelDisplayName': 'Error',
                 'Message': 'Service stopped unexpectedly.'}
        result = {'events': [event], 'warnings': [], 'start_time': '2026-10-12T12:00:00+07:00',
                  'end_time': '2026-10-13T12:00:00+07:00', 'truncated_channels': ['System'],
                  'limit_per_channel': 100, 'timezone': 'Asia/Bangkok (UTC+7)'}
        fake = SimpleNamespace(scan_start_date=Mock(), scan_start_time=Mock(), scan_end_date=Mock(),
                               scan_end_time=Mock(), scan_limit=Mock(), input=Mock(), output=Mock(),
                               status=Mock(), show=Mock(), record={})
        fake.scan_start_date.get.return_value = '2026-10-12'
        fake.scan_start_time.get.return_value = '12:00'
        fake.scan_end_date.get.return_value = '2026-10-13'
        fake.scan_end_time.get.return_value = '12:00'
        fake.scan_limit.get.return_value = '100'
        fake.analyze = Mock()
        fake.scan_done = lambda value: App.scan_done(fake, value)
        fake.background = lambda work, done: done(work())
        with patch('core.scan', return_value=result) as scan:
            App.scan_dates(fake)
        kwargs = scan.call_args.kwargs
        self.assertEqual(kwargs['start'].utcoffset(), timedelta(hours=7))
        self.assertEqual(kwargs['end'].hour, 12)
        self.assertEqual(fake.record['scan']['event_count'], 1)
        self.assertNotIn('events', fake.record['scan'])
        self.assertIn('ถึงเพดาน', fake.status.configure.call_args.kwargs['text'])
        fake.analyze.assert_called_once()

    def test_ui_empty_scan_clears_previous_result(self):
        from app import App
        fake = SimpleNamespace(input=Mock(), output=Mock(), status=Mock(), record={'old': True})
        App.scan_done(fake, {'events': [], 'warnings': ['System: ไม่พบเหตุการณ์'], 'truncated_channels': []})
        self.assertIsNone(fake.record)
        self.assertEqual(fake.output.configure.call_args.kwargs['state'], 'disabled')
        self.assertIn('0 เหตุการณ์', fake.status.configure.call_args.kwargs['text'])


if __name__ == '__main__':
    unittest.main()
