import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch, Mock
import requests
import core

class Tests(unittest.TestCase):
    def test_thai_count(self):
        self.assertGreater(core.word_count('ระบบบันทึกเหตุการณ์ผิดพลาดของโปรแกรม'), 3)

    def test_length_boundaries(self):
        for n in (399, 10001):
            with self.assertRaises(ValueError):
                core.validate(' '.join(['event'] * n), 30)
        for n in (400, 1000, 1001, 10000):
            self.assertEqual(core.validate(' '.join(['event'] * n), 30), n)

    def test_rate(self):
        for n in (19, 41):
            with self.assertRaises(ValueError):
                core.validate('event ' * 400, n)

    def test_rules_and_unknown(self):
        r = core.diagnose('Provider: Microsoft-Windows-Kernel-Power Event ID: 41')
        self.assertEqual(r[0]['rule'], 'unexpected_shutdown')
        self.assertIn('41', r[0]['evidence'][0])
        self.assertEqual(core.diagnose('ordinary unrelated text'), [])

    def test_empty(self):
        with self.assertRaises(ValueError):
            core.make_record(' ')

    def test_sid_numbers_never_trigger_event_id_rules(self):
        self.assertEqual(core.diagnose('SID S-1-5-21-6008-7000-153-2004-1001'), [])

    def test_redaction(self):
        with patch('core.key', return_value='secret-value'):
            self.assertNotIn('secret-value', core.make_record('log secret-value')['source'])

    def test_request_contract(self):
        response = Mock(status_code=200)
        response.json.return_value = [{'summary': 'สรุป'}]
        text = 'event ' * 400
        with patch('core.key', return_value='test-only'), patch('core.requests.post', return_value=response) as post:
            self.assertEqual(core.summarize(text, 30), 'สรุป')
            self.assertEqual(post.call_args.kwargs['json'], [{'id': 1, 'src': text, 'comp_rate': 30}])
            self.assertEqual(post.call_args.kwargs['headers'], {'Apikey': 'test-only'})

    def test_no_request_for_short_input(self):
        with patch('core.requests.post') as post:
            with self.assertRaises(ValueError):
                core.summarize('short')
            post.assert_not_called()

    def test_http_errors(self):
        for code in (401, 403, 429, 500, 302):
            with patch('core.key', return_value='test-only'), patch('core.requests.post', return_value=Mock(status_code=code)):
                with self.assertRaisesRegex(ValueError, str(code)):
                    core.summarize('event ' * 400)

    def test_network(self):
        for error in (requests.Timeout(), requests.ConnectionError()):
            with patch('core.key', return_value='test-only'), patch('core.requests.post', side_effect=error):
                with self.assertRaises(ValueError):
                    core.summarize('event ' * 400)

    def test_invalid_response(self):
        for value in ({'unexpected': 'x'}, '', None):
            response = Mock(status_code=200)
            response.json.return_value = value
            with patch('core.key', return_value='test-only'), patch('core.requests.post', return_value=response):
                with self.assertRaises(ValueError):
                    core.summarize('event ' * 400)

    def test_history(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as folder, patch('core.DATA', Path(folder)):
            record = core.make_record('Event ID: 41')
            core.save(record)
            self.assertEqual(core.history(), [record])
            self.assertIn('AI summary', core.report(record))
            (Path(folder) / 'history.json').write_text('{broken', encoding='utf-8')
            with self.assertRaises(ValueError):
                core.save(record)
            self.assertEqual((Path(folder) / 'history.json').read_text(), '{broken')

    def document(self, words):
        # Unique ASCII word fixtures, never sent to a live API.
        return ' \n'.join('entry' + ''.join(chr(97 + (i // 26**p) % 26) for p in range(4)) for i in range(words)) + '\n'

    def test_split_preserves_all_source(self):
        for words in (400, 1000, 1001, 1399, 2001, 9999, 10000):
            with self.subTest(words=words):
                source = self.document(words)
                parts = core.split_document(source)
                self.assertEqual(''.join(parts), source)
                self.assertTrue(all(400 <= core.word_count(p) <= 1000 for p in parts))
                self.assertEqual(sum(core.word_count(p) for p in parts), words)

    def test_thai_mixed_split(self):
        source = '\n\n'.join(f'เหตุการณ์จริงลำดับ {i} โปรแกรมหยุดทำงานเวลา 12:30 น.\nChannel: Application\n' for i in range(180))
        self.assertGreater(core.word_count(source), 1000)
        parts = core.split_document(source)
        self.assertEqual(''.join(parts), source)
        self.assertTrue(all(400 <= core.word_count(p) <= 1000 for p in parts))

    def test_multipart_request_contract_and_progress(self):
        response = Mock(status_code=200)
        response.json.return_value = 'สรุปจำลอง'
        source = self.document(10000)
        progress = Mock()
        with patch('core.key', return_value='test-only'), patch('core.requests.post', return_value=response) as post:
            result = core.summarize_document(source, 40, progress)
        self.assertTrue(result['complete'])
        self.assertEqual(len(result['parts']), 10)
        self.assertEqual(post.call_count, 10)
        sent = [call.kwargs['json'][0]['src'] for call in post.call_args_list]
        self.assertEqual(''.join(sent), source)
        self.assertTrue(all(call.kwargs['json'][0]['comp_rate'] == 40 for call in post.call_args_list))
        self.assertEqual(progress.call_args_list[-1].args, (10, 10))

    def test_partial_failure_is_not_complete_and_stops(self):
        response = Mock(status_code=200)
        response.json.return_value = 'สรุปส่วนแรก'
        with patch('core.key', return_value='test-only'), patch('core.requests.post', side_effect=[response, requests.Timeout()]) as post:
            result = core.summarize_document(self.document(2500))
        self.assertFalse(result['complete'])
        self.assertEqual(post.call_count, 2)
        self.assertEqual([p['status'] for p in result['parts']], ['success', 'failed', 'not_sent'])
        self.assertIn('ไม่ครบเอกสาร', result['summary'])
        self.assertIn('สรุปส่วนแรก', result['summary'])
        record = core.make_record('Event ID: 41')
        record.update(summary=result['summary'], summary_parts=result['parts'], summary_complete=False)
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as folder, patch('core.DATA', Path(folder)):
            core.save(record)
            self.assertEqual(core.history()[0]['summary_parts'], result['parts'])
            self.assertIn('ไม่ครบเอกสาร', core.report(core.history()[0]))

    def test_all_failed(self):
        with patch('core.key', return_value='test-only'), patch('core.requests.post', return_value=Mock(status_code=500)) as post:
            result = core.summarize_document(self.document(1001))
        self.assertFalse(result['complete'])
        self.assertEqual(post.call_count, 1)
        self.assertIn('สำเร็จ 0/2', result['summary'])

    def test_reject_large_document_before_network(self):
        with patch('core.requests.post') as post:
            with self.assertRaises(ValueError):
                core.summarize_document(self.document(10001))
            post.assert_not_called()

    def test_single_request_still_bounded(self):
        with patch('core.requests.post') as post:
            with self.assertRaises(ValueError):
                core.summarize(self.document(1001))
            post.assert_not_called()

    def test_ui_keeps_partial_result_in_record(self):
        from types import SimpleNamespace
        from queue import Queue
        from app import App
        partial = {'summary': 'สรุป AI ไม่ครบเอกสาร', 'parts': [{'part': 1, 'status': 'failed'}], 'complete': False}
        fake = SimpleNamespace(record=core.make_record(self.document(1001)), analyze=Mock(),
                               rate=Mock(), show=Mock(), status=Mock(), progress=Queue(), input=Mock())
        fake.input.get.return_value = fake.record['source']
        fake.rate.get.return_value = '30'
        fake.background = lambda work, done: done(work())
        with patch('pathumma.analyze', return_value=partial):
            App.ai(fake)
        self.assertFalse(fake.record['summary_complete'])
        self.assertEqual(fake.record['summary_parts'], partial['parts'])
        self.assertIn('ไม่ครบ', fake.status.configure.call_args.kwargs['text'])

if __name__ == '__main__':
    unittest.main()
