import json
import os
import re
import subprocess
import sys
import tempfile
from datetime import datetime, timedelta, timezone
from pathlib import Path

import requests
import evidence
from dotenv import dotenv_values
from pythainlp.tokenize import word_tokenize

BASE = Path(sys.executable).parent if getattr(sys, 'frozen', False) else Path(__file__).resolve().parent
DATA = Path(os.getenv('LOCALAPPDATA', str(Path.home()))) / 'WinSightAI'
ENDPOINT = 'https://api.aiforthai.in.th/textsummarize'

def key():
    return (dotenv_values(BASE / '.env').get('AIFORTHAI_API_KEY') or os.getenv('AIFORTHAI_API_KEY', '')).strip()

def sanitize(text):
    secret = key()
    if secret:
        text = text.replace(secret, '[REDACTED]')
    return re.sub(r'(?i)(apikey|api_key|password|token)\s*[:=]\s*[^\s,;]+', r'\1=[REDACTED]', text)

def word_count(text):
    return len([t for t in word_tokenize(text, engine='newmm') if re.search(r'[\w\u0e00-\u0e7f]', t)])

def validate(text, rate, max_words=10000):
    if not 20 <= int(rate) <= 40:
        raise ValueError('comp_rate ต้องอยู่ระหว่าง 20–40')
    count = word_count(text)
    if not 400 <= count <= max_words:
        raise ValueError(f'เอกสารมี {count} คำ ต้องมี 400–{max_words:,} คำ กรุณาใช้ข้อมูลจริง ไม่เติมซ้ำ')
    return count

def split_document(text, rate=30):
    """Partition at token boundaries; joining parts reproduces the exact source."""
    count = validate(text, rate)
    if count <= 1000:
        return [text]
    tokens = word_tokenize(text, engine='newmm')
    if ''.join(tokens) != text:
        raise ValueError('ตัวตัดคำไม่สามารถรักษาข้อความต้นฉบับครบได้ จึงยกเลิกการส่ง')
    ends, offset = [], 0
    for token in tokens:
        offset += len(token)
        if re.search(r'[\w\u0e00-\u0e7f]', token):
            ends.append(offset)
    # Balance all parts so a small last part (e.g. 1,001 words) is never padded.
    # Recheck each substring because Thai tokenization can depend on context.
    for total in range((count + 999) // 1000, count // 400 + 1):
        quotient, remainder = divmod(count, total)
        parts, start, consumed = [], 0, 0
        for index in range(total):
            consumed += quotient + (index < remainder)
            stop = ends[consumed - 1] if index < total - 1 else len(text)
            parts.append(text[start:stop])
            start = stop
        if all(400 <= word_count(part) <= 1000 for part in parts):
            return parts
    raise ValueError('แบ่งเอกสารเป็นส่วน 400–1000 คำไม่ได้ กรุณาแบ่งตามเหตุการณ์เอง')

def summarize(text, rate=30):
    text = sanitize(text)
    validate(text, rate, max_words=1000)
    secret = key()
    if not secret or secret == 'YOUR_API_KEY_HERE':
        raise ValueError('กรุณาตั้ง AIFORTHAI_API_KEY ใน .env ข้างโปรแกรม')
    try:
        response = requests.post(ENDPOINT, headers={'Apikey': secret},
                                 json=[{'id': 1, 'src': text, 'comp_rate': int(rate)}],
                                 timeout=(10, 60), allow_redirects=False)
    except requests.Timeout:
        raise ValueError('API หมดเวลา ลองใหม่ภายหลัง') from None
    except requests.RequestException:
        raise ValueError('เชื่อมต่อ API ไม่สำเร็จ ตรวจอินเทอร์เน็ต') from None
    if response.status_code != 200:
        reason = 'บริการมีข้อผิดพลาด ลองใหม่ภายหลัง' if response.status_code >= 500 else 'ตรวจสิทธิ์คีย์ โควตา หรือรูปแบบคำขอ'
        raise ValueError(f'API HTTP {response.status_code}: {reason}')
    try:
        value = response.json()
    except ValueError:
        raise ValueError('API ไม่ได้ส่ง JSON ที่อ่านได้') from None
    def extract(v):
        if isinstance(v, str):
            return v.strip()
        if isinstance(v, list):
            return '\n'.join(filter(None, (extract(i) for i in v)))
        if isinstance(v, dict):
            for name in ('summary', 'summarize', 'result', 'output', 'text', 'data'):
                if name in v:
                    return extract(v[name])
        return ''
    output = extract(value)
    if not output:
        raise ValueError('API ส่งรูปแบบผลลัพธ์ที่ไม่รองรับหรือข้อความว่าง')
    return sanitize(output)

def summarize_document(text, rate=30, progress=None):
    text = sanitize(text)
    parts = split_document(text, rate)
    if not key() or key() == 'YOUR_API_KEY_HERE':
        raise ValueError('กรุณาตั้ง AIFORTHAI_API_KEY ใน .env ข้างโปรแกรม')
    results, stopped = [], False
    for index, part in enumerate(parts, 1):
        result = {'part': index, 'words': word_count(part), 'status': 'not_sent'}
        if not stopped:
            if progress:
                progress(index, len(parts))
            try:
                result.update(status='success', summary=summarize(part, rate))
            except ValueError as error:
                result.update(status='failed', error=sanitize(str(error)))
                stopped = True
        results.append(result)
    completed = sum(p['status'] == 'success' for p in results)
    complete = completed == len(parts)
    lines = [f"สรุป AI แยกตามส่วน: สำเร็จ {completed}/{len(parts)} ส่วน — " + ('ครบทุกส่วน' if complete else 'ไม่ครบเอกสาร')]
    for result in results:
        lines.append(f"\nส่วน {result['part']}/{len(parts)} ({result['words']} คำต้นฉบับ)")
        if result['status'] == 'success':
            lines.append(result['summary'])
        elif result['status'] == 'failed':
            lines.append('สรุปไม่สำเร็จ: ' + result['error'])
        else:
            lines.append('ยังไม่ได้ส่ง: หยุดหลังส่วนก่อนหน้าล้มเหลว เพื่อไม่ยิง API ซ้ำต่อเนื่อง')
    return {'summary': '\n'.join(lines), 'parts': results, 'complete': complete}

RULES = [
    ('unexpected_shutdown', r'(?i)Kernel-Power|\bEvent\s*ID\s*[:=]?\s*(?:41|6008)\b', 'พบเหตุการณ์ปิดเครื่องไม่สมบูรณ์', 'ตรวจเวลาเกิดเหตุ ไฟเลี้ยง อุณหภูมิ และเหตุการณ์ก่อนหน้า; ไม่ยืนยันว่า PSU เสีย'),
    ('app_crash', r'(?i)Application Error|\bEvent\s*ID\s*[:=]?\s*(?:1000|1001)\b|faulting application', 'มีหลักฐานโปรแกรม crash หรือรายงานข้อผิดพลาด', 'ตรวจชื่อโปรแกรม faulting module และ exception code ก่อนอัปเดตหรือซ่อมโปรแกรม'),
    ('service', r'(?i)Service Control Manager|\bEvent\s*ID\s*[:=]?\s*(?:7000|7001|7031|7034|7024)\b', 'บริการ Windows อาจเริ่มไม่สำเร็จหรือหยุด', 'ตรวจชื่อบริการ dependency และสิทธิ์จากข้อความเหตุการณ์'),
    ('disk', r'(?i)\bdisk\b|\bntfs\b|bad block|\bEvent\s*ID\s*[:=]?\s*153\b', 'พบข้อความที่อาจเกี่ยวกับ storage', 'ตรวจสุขภาพดิสก์และสำรองข้อมูล; คำว่า disk อย่างเดียวไม่ยืนยันดิสก์เสีย'),
    ('memory', r'(?i)out of memory|resource-exhaustion|\bEvent\s*ID\s*[:=]?\s*2004\b', 'อาจมีทรัพยากรหน่วยความจำไม่พอ', 'ตรวจการใช้ RAM และโปรเซส ณ เวลาเกิดเหตุ'),
]

def diagnose(text):
    if evidence.parse_events(text):
        return evidence.local_findings(text)
    findings = []
    for name, pattern, title, advice in RULES:
        matches = list(re.finditer(pattern, text))
        if matches:
            findings.append({'rule': name, 'finding': title, 'advice': advice,
                             'evidence': [text[max(0, m.start()-60):m.end()+100] for m in matches[:3]],
                             'confidence': 'rule match — ไม่ใช่ความน่าจะเป็นหรือสาเหตุยืนยัน'})
    return findings

THAI_TIMEZONE = timezone(timedelta(hours=7), name='Asia/Bangkok')
MAX_SCAN_DAYS = 31

def parse_scan_datetime(value):
    """Parse an ISO date-time. A value without an offset is Thailand local time."""
    if isinstance(value, datetime):
        parsed = value
    elif isinstance(value, str):
        # Only accepted date-time forms reach the process command. Never interpolate input.
        value = value.strip()
        if not re.fullmatch(r'\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}(?::\d{2}(?:\.\d{1,6})?)?(?:Z|[+-]\d{2}:\d{2})?', value):
            raise ValueError('วัน/เวลาไม่ถูกต้อง ใช้ YYYY-MM-DD และ HH:MM หรือ HH:MM:SS (เวลาไทย UTC+7)')
        try:
            parsed = datetime.fromisoformat(value.replace('Z', '+00:00'))
        except ValueError:
            raise ValueError('วัน/เวลาไม่ถูกต้อง กรุณาตรวจวันที่และเวลาอีกครั้ง') from None
    else:
        raise ValueError('วัน/เวลาต้องเป็นข้อความ ISO หรือ datetime')
    if parsed.tzinfo is None or parsed.utcoffset() is None:
        parsed = parsed.replace(tzinfo=THAI_TIMEZONE)
    return parsed.astimezone(THAI_TIMEZONE)

def scan_range(start, end):
    start, end = parse_scan_datetime(start), parse_scan_datetime(end)
    if start > end:
        raise ValueError('วัน/เวลาเริ่มต้องไม่อยู่หลังวัน/เวลาสิ้นสุด')
    if end - start > timedelta(days=MAX_SCAN_DAYS):
        raise ValueError(f'เลือกช่วงเวลาได้สูงสุด {MAX_SCAN_DAYS} วันต่อครั้ง กรุณาแบ่งช่วงเวลา')
    return start, end

def _scan_number(value, label, minimum, maximum):
    if isinstance(value, bool) or not re.fullmatch(r'\d+', str(value)):
        raise ValueError(f'{label}ต้องเป็นจำนวนเต็ม {minimum}–{maximum}')
    number = int(value)
    if not minimum <= number <= maximum:
        raise ValueError(f'{label}ต้องอยู่ระหว่าง {minimum}–{maximum}')
    return number

def scan(hours=24, limit=100, *, start=None, end=None):
    if sys.platform != 'win32':
        raise ValueError('อ่าน Windows Events รองรับ Windows เท่านั้น')
    limit = _scan_number(limit, 'จำนวนสูงสุดต่อ channel ', 1, 500)
    if (start is None) != (end is None):
        raise ValueError('กรุณาระบุทั้งวัน/เวลาเริ่มและวัน/เวลาสิ้นสุด')
    if start is None:
        hours = _scan_number(hours, 'ชั่วโมงย้อนหลัง ', 1, 168)
        end = datetime.now(THAI_TIMEZONE)
        start = end - timedelta(hours=hours)
    else:
        start, end = scan_range(start, end)
    # Convert known datetime values to canonical UTC strings; raw user input cannot
    # become PowerShell source. LocalDateTime represents the same instant in the OS zone.
    start_iso = start.astimezone(timezone.utc).isoformat(timespec='microseconds')
    end_iso = end.astimezone(timezone.utc).isoformat(timespec='microseconds')
    script = """$ErrorActionPreference='Stop'; [Console]::OutputEncoding=[System.Text.UTF8Encoding]::new();
    Import-Module (Join-Path $PSHOME 'Modules\\Microsoft.PowerShell.Diagnostics\\Microsoft.PowerShell.Diagnostics.psd1') -ErrorAction Stop;
    $start=[DateTimeOffset]::Parse('START_ISO',[Globalization.CultureInfo]::InvariantCulture).LocalDateTime;
    $end=[DateTimeOffset]::Parse('END_ISO',[Globalization.CultureInfo]::InvariantCulture).LocalDateTime;
    $rows=@(); $warnings=@(); $truncated=@(); foreach($channel in @('Application','System')) {
      try { $batch=@(Get-WinEvent -FilterHashtable @{LogName=$channel;StartTime=$start;EndTime=$end;Level=1,2,3} -MaxEvents READ_LIMIT -ErrorAction Stop);
      if($batch.Count -gt RESULT_LIMIT) { $truncated += $channel };
      $rows += @($batch | Select-Object -First RESULT_LIMIT |
      Select-Object @{N='Time';E={$_.TimeCreated.ToString('o')}},Id,@{N='LevelDisplayName';E={switch($_.Level){1{'Critical'} 2{'Error'} 3{'Warning'} default{$_.LevelDisplayName}}}},ProviderName,LogName,Message) }
      catch { $id=$_.FullyQualifiedErrorId; if($id -like '*NoMatchingEventsFound*') { $warnings += ($channel + ': ไม่พบเหตุการณ์ในช่วงที่เลือก') }
      elseif($id -like '*UnauthorizedAccess*') { $warnings += ($channel + ': ไม่มีสิทธิ์อ่าน Windows Events (' + $id + ')') }
      else { $warnings += ($channel + ': อ่านไม่สำเร็จ (' + $id + ')') } }
    }; ConvertTo-Json -Depth 5 -InputObject @{events=@($rows | Sort-Object Time -Descending);warnings=@($warnings);truncated_channels=@($truncated)}"""
    script = (script.replace('START_ISO', start_iso).replace('END_ISO', end_iso)
              .replace('READ_LIMIT', str(limit + 1)).replace('RESULT_LIMIT', str(limit)))
    try:
        result = subprocess.run(['powershell.exe', '-NoProfile', '-NonInteractive', '-Command', script],
                                capture_output=True, timeout=60, creationflags=0x08000000)
    except (OSError, subprocess.TimeoutExpired):
        raise ValueError('อ่าน Windows Events ไม่สำเร็จหรือหมดเวลา') from None
    if result.returncode:
        raise ValueError('Windows ไม่อนุญาตให้อ่าน log')
    try:
        value = json.loads(result.stdout.decode('utf-8-sig'))
        if not isinstance(value, dict) or not isinstance(value.get('events'), list) or not isinstance(value.get('warnings'), list):
            raise ValueError()
        value.update(start_time=start.isoformat(), end_time=end.isoformat(),
                     timezone='Asia/Bangkok (UTC+7)', limit_per_channel=limit)
        return value
    except (ValueError, UnicodeError):
        raise ValueError('อ่านผล Windows Events ไม่สำเร็จ') from None

def event_text(events):
    return '\n\n'.join(f"เวลา: {e['Time']} | Channel: {e['LogName']} | Event ID: {e['Id']} | Provider: {e['ProviderName']} | Level: {e['LevelDisplayName']}\n{e['Message']}" for e in events)

def report(record):
    rows = ['WinSight AI v1.1.1', record['time'], '', 'ภาพรวมจากหลักฐานจริง — Local summary',
            record.get('local_summary') or evidence.local_summary(record['source'])]
    if record.get('scan'):
        scan_data = record['scan']
        rows.extend(['', 'ขอบเขตการอ่าน Windows Events',
                     f"{scan_data.get('start_time', '?')} ถึง {scan_data.get('end_time', '?')}",
                     f"เพดาน {scan_data.get('limit_per_channel', '?')} รายการต่อ channel"])
        if scan_data.get('truncated_channels'):
            rows.append('ถึงเพดานข้อมูลใน: ' + ', '.join(scan_data['truncated_channels']) + ' — ภาพรวมครอบคลุมเฉพาะรายการที่อ่านมา')
    rows.extend(['', 'ข้อสังเกตและสิ่งที่ควรตรวจ — ไม่ยืนยันสาเหตุ'])
    if not record['diagnosis']:
        rows.append('ไม่พบกฎตรงกับข้อความนี้ ยังไม่ใช่หลักฐานว่าไม่มีปัญหา')
    for finding in record['diagnosis']:
        if re.fullmatch(r'E\d{3}', finding.get('rule', '')):
            rows.append(f"• [{finding['rule']}] {finding['advice']}")
        else:
            rows.append(f"• {finding['finding']}\n  {finding['advice']}")
    rows.extend(['', 'AI summary — อาจคลาดเคลื่อน ไม่ใช่หลักฐานหรือการวินิจฉัยแน่นอน',
                 record.get('summary') or 'ยังไม่ได้เรียก API', '', 'หลักฐานจริง (ข้อมูลที่รับเข้า)', record['source']])
    return '\n'.join(rows)

def history():
    path = DATA / 'history.json'
    if not path.exists():
        return []
    try:
        records = json.loads(path.read_text(encoding='utf-8'))
        if not isinstance(records, list):
            raise ValueError()
        return records
    except (ValueError, OSError):
        raise ValueError('History อ่านไม่ได้ กรุณาสำรองและตรวจไฟล์ history.json') from None

def save(record):
    records = history()
    records.append(record)
    DATA.mkdir(parents=True, exist_ok=True)
    fd, temp = tempfile.mkstemp(dir=DATA, suffix='.tmp')
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as f:
            json.dump(records[-100:], f, ensure_ascii=False, indent=2)
        os.replace(temp, DATA / 'history.json')
    finally:
        if Path(temp).exists():
            Path(temp).unlink()

def make_record(text):
    text = sanitize(evidence.extract_source(text.strip()))
    if not text:
        raise ValueError('กรุณาใส่ข้อความ log')
    return {'time': datetime.now(timezone.utc).isoformat(), 'source': text, 'diagnosis': diagnose(text),
            'local_summary': evidence.local_summary(text), 'summary': ''}
