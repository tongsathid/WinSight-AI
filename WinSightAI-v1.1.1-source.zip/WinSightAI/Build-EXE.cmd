@echo off
cd /d "%~dp0"
".venv\Scripts\python.exe" -m PyInstaller --noconfirm --clean --onedir --windowed --name WinSightAI --collect-all customtkinter --collect-all pythainlp app.py
pause
